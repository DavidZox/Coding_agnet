"""ArchiveMixin：工具回傳的原文存檔（logs/tool_results/<session>_<編號>_<腳本>.md）與 index.md。"""
import os
import re
import time
from skills_system.scripts import _results_common
from .config import (
    CONVERSATION_SEGMENTS_KEEP,
    TOOL_RESULT_FILE_RE,
    TOOL_RESULTS_DIRNAME,
    TOOL_RESULTS_INDEX,
    TOOL_RESULTS_KEEP,
    TOOL_RESULTS_MAX_MB,
    VISION_ARCHIVE_SCRIPT,
    VISION_RESULTS_KEEP,
)
from .tool_use_index import result_kind


class ArchiveMixin:

    # ---------------------------------------------------------------- 📄 工具結果存檔
    def results_dir(self):
        return os.path.join(self.script_dir, "logs", TOOL_RESULTS_DIRNAME)

    def _max_archived_id(self):
        """既有存檔裡最大的編號（沒有存檔就 0）：__init__ 用它當 trajectory_seq 的起點，讓編號跨 session 不重複。"""
        return max((f[1] for f in _results_common.list_result_files(self.results_dir())), default=0)

    def _archive_tool_result(self, record, output_text):
        """把一次腳本執行的完整原始輸出寫成 logs/tool_results/<session>_<id>_<腳本>.md，並在 index.md 追加一行。
        檔頭是簡單的 key: value（宿主機不一定有 PyYAML）。寫不進去不影響主流程（回傳 None）。"""
        try:
            d = self.results_dir()
            os.makedirs(d, exist_ok=True)
            stem = re.sub(r"[^A-Za-z0-9_-]", "_", re.sub(r"(_cmd)?\.py$", "", record["script"]))
            filename = f"{self.session_id}_{record['id']:03d}_{stem}.md"
            task = " ".join((record.get("task") or "").split())
            header = [
                "---", f"id: {record['id']}", f"session: {self.session_id}", f"ts: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                f"script: {record['script']}", f"skill: {record.get('skill') or ''}", f"command: {record['command']}",
                f"cwd: {record['cwd']}", f"container: {record.get('target_container') or ''}", f"status: {record['status']}",
                f"chars: {len(output_text)}", f"task: {task}", "---",
            ]
            with open(os.path.join(d, filename), "w", encoding="utf-8") as f:
                f.write("\n".join(header) + "\n" + output_text + ("\n" if not output_text.endswith("\n") else ""))
            line = (f"#{record['id']} | {time.strftime('%Y-%m-%d %H:%M')} | {record['script']} | {record['status']} | "
                    f"{len(output_text)} 字 | {filename} | 任務：{task} | 回答：")   # 任務與回答整句照存、不截斷（result_list 直接列這一行）
            with open(os.path.join(d, TOOL_RESULTS_INDEX), "a", encoding="utf-8") as f:
                f.write(line + "\n")
            self._prune_tool_results(d)
            return filename
        except OSError:
            return None

    def _prune_tool_results(self, d):
        """工具回傳只留最近 TOOL_RESULTS_KEEP 個檔、總大小不超過 TOOL_RESULTS_MAX_MB；被壓縮的對話片段另外只看
        CONVERSATION_SEGMENTS_KEEP、附圖分析只看 VISION_RESULTS_KEEP——三種分開算，工具跑得再多也不會把對話原文或附圖分析
        擠掉（這兩種沒辦法重跑一次拿回來：對話已經過去、原圖沒有保存）。刪最舊的並把 index.md 裡對應的行拿掉。"""
        names = sorted(fn for fn in os.listdir(d) if TOOL_RESULT_FILE_RE.match(fn))   # 檔名＝session_id + 三位數編號，排序即時間順序
        convs = [fn for fn in names if result_kind(fn) == "conversation"]
        visions = [fn for fn in names if result_kind(fn) == "vision"]
        tools = [fn for fn in names if result_kind(fn) == "tool"]
        sizes = {fn: os.path.getsize(os.path.join(d, fn)) for fn in tools}
        total, removed = sum(sizes.values()), []
        while tools and (len(tools) > TOOL_RESULTS_KEEP or total > TOOL_RESULTS_MAX_MB * 1024 * 1024):
            fn = tools.pop(0)
            total -= sizes[fn]
            os.remove(os.path.join(d, fn))
            removed.append(fn)
        for pool, keep in ((convs, CONVERSATION_SEGMENTS_KEEP), (visions, VISION_RESULTS_KEEP)):
            while len(pool) > max(keep, 1):
                fn = pool.pop(0)
                os.remove(os.path.join(d, fn))
                removed.append(fn)
        if removed:
            index = os.path.join(d, TOOL_RESULTS_INDEX)
            if os.path.exists(index):
                with open(index, encoding="utf-8") as f:
                    lines = [ln for ln in f.read().splitlines() if not any(f"| {fn} |" in ln for fn in removed)]
                with open(index, "w", encoding="utf-8") as f:
                    f.write("\n".join(lines) + ("\n" if lines else ""))
        return removed

    def archive_vision_result(self, text, hint, sources, answer=""):
        """附圖的視覺分析結果存成一份存檔（跟工具回傳同一套 #編號、同一個目錄，腳本欄寫 vision_extract），index.md 的
        「回答」欄填視覺模型的重點，並記進工具使用檢索清單（描述是視覺模型寫的 index_hint，system prompt 顯示時標〔附圖分析〕）。
        以前視覺分析只併進那一則使用者訊息：訊息被壓縮或換了 session 之後，main session 與獨立 session 都找不到它，也沒辦法
        像工具回傳一樣 result_recall。原圖不存（只存給決策 AI 看的文字），所以 recall 時只能根據這份文字回答（見 _result_recall）。
        不記進操作軌跡：它不是執行腳本，/make_skill 不該把它當成一個步驟。回傳編號；寫不進去回 None（不影響主流程）。"""
        if not str(text or "").strip():
            return None
        rid = self._next_id()
        listed = "；".join(f"影像 {i} {src}" for i, src in enumerate(sources or [], 1))
        record = {"id": rid, "script": VISION_ARCHIVE_SCRIPT, "skill": "", "status": "PASS",
                  "command": f"（附圖的視覺分析，{len(sources or [])} 張影像" + (f"：{listed}" if listed else "") + "）",
                  "cwd": self.current_cwd, "target_container": self.target_container, "task": self.current_task or ""}
        filename = self._archive_tool_result(record, text)
        if not filename:
            return None
        self.update_result_answer(rid, answer)
        self._append_tool_use_index(rid, filename, hint)
        return rid

    def update_result_answer(self, result_id, answer):
        """摘要 session 產出「回答」後回填到 index.md 該筆的「回答：」欄，result_list 一眼就能看到每個存檔在講什麼。"""
        if not result_id or not answer:
            return False
        try:
            index = os.path.join(self.results_dir(), TOOL_RESULTS_INDEX)
            with open(index, encoding="utf-8") as f:
                lines = f.read().splitlines()
            key = f"#{result_id} | "
            for i, ln in enumerate(lines):
                if ln.startswith(key) and f"| {self.session_id}_" in ln:
                    lines[i] = ln.rsplit("| 回答：", 1)[0] + "| 回答：" + " ".join(answer.split())
                    break
            else:
                return False
            with open(index, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            return True
        except OSError:
            return False

    def result_file_path(self, ref):
        """'16'／'#16'（優先目前 session）、'latest'、'index' 或檔名 → 完整路徑；找不到回 None。Web 的 /api/results/<ref> 用。"""
        d = self.results_dir()
        if not os.path.isdir(d):
            return None
        ref = str(ref or "").strip()
        if ref == "index":
            p = os.path.join(d, TOOL_RESULTS_INDEX)
            return p if os.path.exists(p) else None
        names = sorted(fn for fn in os.listdir(d) if TOOL_RESULT_FILE_RE.match(fn))
        if ref.lstrip("#").isdigit():
            rid = int(ref.lstrip("#"))
            cands = [fn for fn in names if fn.split("_")[2] == f"{rid:03d}"]
            mine = [fn for fn in cands if fn.startswith(self.session_id + "_")]
            chosen = (mine or cands)
            return os.path.join(d, chosen[-1]) if chosen else None
        if ref in ("latest", "last"):
            return os.path.join(d, names[-1]) if names else None
        base = os.path.basename(ref)
        return os.path.join(d, base) if base in names else None
