"""給 Ollama format= 的 JSON schema：主對話回覆、滾動摘要、工具摘要、技能草稿。"""


# 🧷 回覆協議：模型每次回覆都是一個 JSON 物件 {thought, reply, action}。執行與否只看 action 欄位，
# reply 裡不論寫了什麼（包括解釋、舉例時抄出來的 `EXECUTE: ...` 字串）都不會被執行——這是「實體隔離」：
# 給人看的文字與給系統執行的指令分開存放，不再用文字比對從回覆裡找指令。以 Ollama 的 format= schema 強制
# 結構（與摘要、make_skill 同一機制），小模型不需要自律「解釋時不要輸出指令」。
# action 為 null 或 {"command": 技能名稱｜規格標明的腳本路徑, "args": 參數字串}；args 是字串而不是物件，
# 因為所有技能腳本都吃位置參數、規格文件的寫法也是位置參數，這樣既有的 tools/*.md 一份都不用改：
# 規格裡的 `EXECUTE: <路徑> <參數>` 範例就對應 command=<路徑>、args=<參數>。
AGENT_REPLY_SCHEMA = {
    "type": "object",
    "properties": {
        "thought": {"type": "string"},
        "reply": {"type": "string"},
        "action": {"anyOf": [
            {"type": "null"},
            {
                "type": "object",
                "properties": {"command": {"type": "string"}, "args": {"type": "string"}},
                "required": ["command", "args"],
            },
        ]},
    },
    "required": ["thought", "reply", "action"],
}

# /make_skill 的流程技能草稿（Ollama format=）：欄位意義見 SkillAgent._make_skill_prompts，驗證見 _normalize_skill_draft。
# 欄位順序＝生成順序：先讀完對話寫用途，再逐條列出使用者的要求（requirements），然後才寫需要的資訊與步驟——實測
# 直接寫步驟時，e4b 與 26b 都會漏掉使用者說過的條件（「低電量的車不要派任務」「派之前先跟我確認」）；
# 最後才寫標題與索引描述（根據寫好的內容總結）。
# 陣列與字串都有上限（同視覺提取的教訓：小模型偶爾會在陣列或字串裡失控，有上限就一定是合法的 JSON）。
MAKE_SKILL_STEP_KINDS = ["執行", "確認", "檢查", "告知"]


def _text(n):
    return {"type": "string", "maxLength": n}


MAKE_SKILL_SCHEMA = {
    "type": "object",
    "properties": {
        "purpose": _text(400),
        "requirements": {
            "type": "array",
            "maxItems": 8,
            "items": {
                "type": "object",
                "properties": {"said": _text(150), "rule": _text(150), "step": {"type": "integer"}},
                "required": ["said", "rule", "step"],
            },
        },
        "inputs": {
            "type": "array",
            "maxItems": 8,
            "items": {
                "type": "object",
                "properties": {"name": _text(40), "description": _text(120), "source": _text(80), "example": _text(120)},
                "required": ["name", "description", "source", "example"],
            },
        },
        "steps": {
            "type": "array",
            "maxItems": 15,
            "items": {
                "type": "object",
                "properties": {
                    "kind": {"type": "string", "enum": MAKE_SKILL_STEP_KINDS},
                    "instruction": _text(300),
                    "skill": _text(40),
                    "command": _text(300),
                    "on_failure": _text(200),
                },
                "required": ["kind", "instruction", "skill", "command", "on_failure"],
            },
        },
        "success_criteria": _text(200),
        "pitfalls": {"type": "array", "maxItems": 8, "items": _text(150)},
        "title": _text(30),
        "description": _text(100),
        "category": _text(40),
    },
    "required": ["purpose", "requirements", "inputs", "steps", "success_criteria", "pitfalls", "title", "description",
                 "category"],
}

# 融合摘要的 JSON schema：交給 Ollama 的 format= 做結構化輸出，再由 _render_summary_markdown 排版。
SUMMARY_SCHEMA = {
    "type": "object",
    "properties": {
        "overview": {"type": "string"},
        "key_progress": {"type": "array", "items": {"type": "string"}},
        "results_and_errors": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "category": {"type": "string"},
                    "description": {"type": "string"},
                    "detail": {"type": "string"},
                },
                "required": ["category", "description", "detail"],
            },
        },
        "user_preferences": {"type": "array", "items": {"type": "string"}},
        "open_items": {"type": "array", "items": {"type": "string"}},
        # 只描述「這次被壓掉的那一段」（不是整份滾動摘要），寫進檢索清單的「過去的對話片段」，日後靠它認出要 recall 哪一段
        "segment_hint": {"type": "string"},
    },
    "required": ["overview", "key_progress", "results_and_errors", "user_preferences", "open_items", "segment_hint"],
}

# 任務導向摘要的結構（Ollama format=）：answer 一句話回答這一步的目的、facts 照抄的相關事實、errors 錯誤原文、
# not_covered 原始輸出沒有／被省略而無法確認的部分——讓主模型知道「摘要裡沒有」不等於「輸出裡沒有」。
TOOL_SUMMARY_SCHEMA = {
    "type": "object",
    "properties": {
        "answer": {"type": "string"},
        "facts": {"type": "array", "items": {"type": "string"}},
        "errors": {"type": "array", "items": {"type": "string"}},
        "not_covered": {"type": "string"},
        "suggested_questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"question": {"type": "string"}, "keywords": {"type": "string"}},
                "required": ["question", "keywords"],
            },
        },
        "index_hint": {"type": "string"},
        "related_records": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "string"}, "reason": {"type": "string"}},
                "required": ["id", "reason"],
            },
        },
    },
    "required": ["answer", "facts", "errors", "not_covered", "suggested_questions", "index_hint", "related_records"],
}


# /plan 草稿（PlanMixin）：第一版由規劃 session 產生整份步驟；之後的自然語言修改只輸出「要套用的操作」，
# 不重寫整份——小模型重寫時會把 4 步變 2 步、把沒提到的步驟改掉。操作由 harness 套用在保存的草稿上。
PLAN_DRAFT_SCHEMA = {
    "type": "object",
    "properties": {
        "steps": {"type": "array", "items": {
            "type": "object",
            "properties": {"skill": {"type": "string"}, "goal": {"type": "string"}},
            "required": ["skill", "goal"],
        }},
    },
    "required": ["steps"],
}

PLAN_OPS_SCHEMA = {
    "type": "object",
    "properties": {
        "ops": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "op": {"type": "string", "enum": ["add", "insert", "edit", "delete", "move"]},
                "step": {"type": "integer"},
                "to": {"type": "integer"},
                "skill": {"type": "string"},
                "goal": {"type": "string"},
            },
            "required": ["op", "step", "to", "skill", "goal"],
        }},
    },
    "required": ["ops"],
}


# 🧑‍💻 Coding orchestrator 的規劃 session（agent_core/coding_planner.py）。跟 MAKE_SKILL_SCHEMA 一樣，陣列與字串都有上限：
# 小模型偶爾會在陣列裡失控，有上限就一定是合法、而且不會長到離譜的 JSON。
# scout：看完專案地圖後，先挑出規劃前需要讀完整內容的檔案（harness 讀好再交給 plan）。
CODE_SCOUT_SCHEMA = {
    "type": "object",
    "properties": {
        "understanding": _text(500),
        "files_to_read": {"type": "array", "maxItems": 6, "items": _text(200)},
        "questions": {"type": "array", "maxItems": 3, "items": _text(200)},
    },
    "required": ["understanding", "files_to_read", "questions"],
}

_CODE_ITEM = {
    "type": "object",
    "properties": {
        "title": _text(60),
        "goal": _text(900),
        "files": {"type": "array", "maxItems": 6, "items": _text(200)},
        "context_files": {"type": "array", "maxItems": 6, "items": _text(200)},
        "verify": _text(200),
    },
    "required": ["title", "goal", "files", "context_files", "verify"],
}

CODE_PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": _text(500),
        "items": {"type": "array", "maxItems": 10, "items": _CODE_ITEM},
        "final_verify": _text(200),
        "risks": {"type": "array", "maxItems": 4, "items": _text(200)},
    },
    "required": ["summary", "items", "final_verify", "risks"],
}

# 用說的改計畫：只輸出要套用的操作（同 PLAN_OPS_SCHEMA 的理由：小模型重寫整份會改掉沒提到的項目）
CODE_PLAN_OPS_SCHEMA = {
    "type": "object",
    "properties": {
        "ops": {"type": "array", "maxItems": 8, "items": {
            "type": "object",
            "properties": {
                "op": {"type": "string", "enum": ["add", "insert", "edit", "delete", "move"]},
                "step": {"type": "integer"},
                "to": {"type": "integer"},
                "title": _text(60),
                "goal": _text(900),
                "files": {"type": "array", "maxItems": 6, "items": _text(200)},
                "verify": _text(200),
            },
            "required": ["op", "step", "to", "title", "goal", "files", "verify"],
        }},
        "final_verify": _text(200),
    },
    "required": ["ops", "final_verify"],
}
